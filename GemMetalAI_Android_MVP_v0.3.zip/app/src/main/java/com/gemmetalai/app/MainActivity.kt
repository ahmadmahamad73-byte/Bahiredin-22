package com.gemmetalai.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.compose.rememberAsyncImagePainter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GemMetalApp() }
    }
}

enum class Lang { AR, EN, AM }
fun tr(l: Lang, ar: String, en: String, am: String) = when(l) { Lang.AR -> ar; Lang.EN -> en; Lang.AM -> am }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GemMetalApp() {
    var lang by remember { mutableStateOf(Lang.AR) }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var locationText by remember { mutableStateOf("") }
    var locationStatus by remember { mutableStateOf("") }
    var weightAir by remember { mutableStateOf("") }
    var weightWater by remember { mutableStateOf("") }
    var showDensity by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) }\n    var workMode by remember { mutableStateOf("explore") }
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { imageUri = it }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) {
            val loc = getLastLocation(context)
            if (loc != null) locationText = String.format(Locale.US, "%.5f, %.5f", loc.latitude, loc.longitude)
            locationStatus = if (loc == null) tr(lang,"لم يصل GPS بعد. جرّب في مكان مفتوح أو أدخل المنطقة يدوياً.","GPS fix unavailable yet. Try outdoors or enter the area manually.","GPS አልተገኘም። ውጭ ቦታ ይሞክሩ ወይም አካባቢውን በእጅ ያስገቡ።")
                else tr(lang,"تم تحديد الإحداثيات على الجهاز.","Coordinates obtained on device.","መጋጠሚያዎች ተገኝተዋል።")
        } else locationStatus = tr(lang,"لم تمنح إذن الموقع. يمكنك إدخال المنطقة يدوياً.","Location permission denied. You can enter the area manually.","የቦታ ፈቃድ አልተሰጠም። አካባቢውን በእጅ ያስገቡ።")
    }
    val density = runCatching {
        val a = weightAir.toDouble()
        val w = weightWater.toDouble()
        if (a > w && w >= 0) a / (a - w) else null
    }.getOrNull()

    MaterialTheme(colorScheme = lightColorScheme(primary=Color(0xFF174B45), secondary=Color(0xFFB88A42), background=Color(0xFFF6F5F0), surface=Color.White)) {
        CompositionLocalProvider(LocalLayoutDirection = if(lang==Lang.AR) androidx.compose.ui.unit.LayoutDirection.Rtl else androidx.compose.ui.unit.LayoutDirection.Ltr) {
            Scaffold(topBar = { TopAppBar(title={Text("Gem & Metal AI",fontWeight=FontWeight.Bold)}, actions={
                TextButton(onClick={lang=when(lang){Lang.AR->Lang.EN;Lang.EN->Lang.AM;Lang.AM->Lang.AR}}) {
                    Text(when(lang){Lang.AR->"عربي";Lang.EN->"English";Lang.AM->"አማርኛ"})
                }
            }) }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).background(Color(0xFFF6F5F0)).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text(tr(lang,"مساعد ميداني للأحجار والمعادن في إثيوبيا","Field assistant for Ethiopian gems & minerals","በኢትዮጵያ የድንጋይና ማዕድን የመስክ ረዳት"), style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold,color=Color(0xFF174B45))
                    Text(tr(lang,"صوّر العينة، حدّد موقع العثور عليها، ثم أدخل نتائج الاختبارات البسيطة.","Photograph the sample, record where it was found, then enter simple test measurements.","ናሙናውን ፎቶ ያንሱ፣ የተገኘበትን ቦታ ይመዝግቡ፣ የቀላል ሙከራ ውጤቶችን ያስገቡ።"))
                    Text(tr(lang,"اختر طريقة الاستخدام","Choose how to use the app","መተግበሪያውን የሚጠቀሙበትን ዘዴ ይምረጡ"),fontWeight=FontWeight.Bold)
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp), modifier=Modifier.fillMaxWidth()) {
                        FilterChip(selected=workMode=="explore", onClick={workMode="explore"},
                            label={Text(tr(lang,"استكشاف ميداني","Field exploration","የመስክ ፍለጋ"))})
                        FilterChip(selected=workMode=="sample", onClick={workMode="sample"},
                            label={Text(tr(lang,"فحص عينة","Sample inspection","ናሙና ምርመራ"))})
                    }
                    Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF1EE))) {
                        Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                            Text(if(workMode=="explore") tr(lang,"وضع الاستكشاف بالكاميرا","Camera exploration mode","በካሜራ የመስክ ፍለጋ") else tr(lang,"وضع فحص صورة عينة","Sample photo inspection","የናሙና ፎቶ ምርመራ"),fontWeight=FontWeight.Bold)
                            Text(if(workMode=="explore") tr(lang,"الفكرة: يوجّه المستخدم الكاميرا إلى الصخور والمكاشف. يقارن النظام المشهد مع الخرائط الجيولوجية وسجل الموقع، ثم يعرض مؤشرات استكشافية غير مؤكدة مثل صخور حاملة للكوارتز أو أكاسيد الحديد أو عروق معدنية محتملة.","Concept: point the camera at outcrops. The system compares the scene with geological maps and location records, then shows tentative field clues such as quartz veins, iron-oxide staining, or possible mineralized structures.","ሀሳቡ፦ ካሜራውን ወደ ድንጋይ ማቅረቢያ ያቅኑ። ስርዓቱ ምስሉን ከጂኦሎጂ ካርታና ከቦታ መዝገቦች ጋር ያወዳድራል።") else tr(lang,"ارفع صورة قريبة وواضحة للحجر من أكثر من زاوية، ثم أضف الوزن والكثافة والاختبارات التي أجريتها. يمكن إرسال التقرير إلى خبير بعيد.","Upload clear close-up photos from multiple angles, then add weight, density, and field-test results. A report can be shared with a remote expert.","ከብዙ አቅጣጫ ግልጽ ፎቶዎችን ያስገቡ፣ ክብደትና የሙከራ ውጤቶችን ይጨምሩ። ሪፖርቱን ለሩቅ ባለሙያ ማጋራት ይቻላል።"),style=MaterialTheme.typography.bodySmall)
                        }
                    }
                    Card(shape=RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            Text(if(workMode=="explore") tr(lang,"1. مشهد المنطقة أو الصخور","1. Area / outcrop view","1. የአካባቢ ወይም የድንጋይ ምስል") else tr(lang,"1. صورة العينة","1. Sample photo","1. የናሙና ፎቶ"),fontWeight=FontWeight.Bold)
                            if(imageUri!=null) Image(painter=rememberAsyncImagePainter(imageUri),contentDescription=null,modifier=Modifier.fillMaxWidth().height(190.dp),contentScale=ContentScale.Fit)
                            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                Button(onClick={picker.launch("image/*")},modifier=Modifier.weight(1f)){Icon(Icons.Default.Image,null);Text(tr(lang,"اختيار صورة","Choose image","ፎቶ ይምረጡ"))}
                                OutlinedButton(onClick={
                                    val i=Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                                    if(i.resolveActivity(context.packageManager)!=null) context.startActivity(i) else picker.launch("image/*")
                                },modifier=Modifier.weight(1f)){Icon(Icons.Default.CameraAlt,null);Text(tr(lang,"الكاميرا","Camera","ካሜራ"))}
                            }
                        }
                    }
                    Card(shape=RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(9.dp)) {
                            Text(tr(lang,"2. موقع العثور على العينة","2. Find location","2. የተገኘበት ቦታ"),fontWeight=FontWeight.Bold)
                            OutlinedButton(onClick={
                                val fine=ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED
                                val coarse=ContextCompat.checkSelfPermission(context,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
                                if(fine||coarse) {
                                    val loc=getLastLocation(context)
                                    if(loc!=null) locationText=String.format(Locale.US,"%.5f, %.5f",loc.latitude,loc.longitude)
                                    locationStatus=if(loc==null) tr(lang,"تعذر الحصول على الموقع حالياً.","Could not obtain location right now.","አሁን ቦታውን ማግኘት አልተቻለም።") else tr(lang,"تم تحديد الإحداثيات.","Coordinates obtained.","መጋጠሚያዎች ተገኝተዋል።")
                                } else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION))
                            },modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.LocationOn,null);Text(tr(lang,"استخدام GPS","Use GPS","GPS ይጠቀሙ"))}
                            OutlinedTextField(value=locationText,onValueChange={locationText=it},modifier=Modifier.fillMaxWidth(),label={Text(tr(lang,"الإحداثيات أو اسم المنطقة","Coordinates or area name","መጋጠሚያዎች ወይም የአካባቢ ስም"))})
                            if(locationStatus.isNotBlank()) Text(locationStatus,style=MaterialTheme.typography.bodySmall,color=Color.Gray)
                            Text(tr(lang,"في الإصدار المتصل سيُستخدم الموقع للبحث في خرائط وتقارير المعهد الجيولوجي الإثيوبي، وليس لإثبات وجود خام في النقطة نفسها.","In the online release, this location will query Ethiopian geological maps and reports; it does not prove a deposit at the exact point.","በኦንላይን ስሪት ቦታው በኢትዮጵያ ጂኦሎጂ ተቋም ካርታዎችና ሪፖርቶች ላይ ለመፈለግ ይጠቅማል።"),style=MaterialTheme.typography.bodySmall,color=Color.Gray)
                        }
                    }
                    Card(shape=RoundedCornerShape(18.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                            Text(tr(lang,"3. اختبار الكثافة بالماء","3. Water-displacement specific gravity","3. በውሃ የተወሰነ ክብደት ሙከራ"),fontWeight=FontWeight.Bold)
                            Text(tr(lang,"زِن الحجر جافاً في الهواء، ثم زِنه معلّقاً ومغموراً بالكامل في الماء دون ملامسة الوعاء. استخدم الغرام في القياسين.","Weigh the dry sample in air, then weigh it fully submerged and suspended in water without touching the container. Use grams for both readings.","ደረቅ ናሙናውን በአየር ይመዝኑ፣ ከዚያ በውሃ ውስጥ ሙሉ በሙሉ ተንጠልጥሎ ይመዝኑ። በሁለቱም ግራም ይጠቀሙ።"),style=MaterialTheme.typography.bodySmall)
                            OutlinedTextField(value=weightAir,onValueChange={weightAir=it},label={Text(tr(lang,"الوزن في الهواء (غرام)","Weight in air (g)","በአየር ክብደት (ግራም)"))},modifier=Modifier.fillMaxWidth())
                            OutlinedTextField(value=weightWater,onValueChange={weightWater=it},label={Text(tr(lang,"الوزن المعلّق في الماء (غرام)","Suspended weight in water (g)","በውሃ ውስጥ ክብደት (ግራም)"))},modifier=Modifier.fillMaxWidth())
                            if(density!=null) Text(tr(lang,"الكثافة النوعية التقريبية: %.2f".format(Locale.US,density),"Approximate specific gravity: %.2f".format(Locale.US,density),"ግምታዊ የተወሰነ ክብደት: %.2f".format(Locale.US,density)),fontWeight=FontWeight.Bold,color=Color(0xFF174B45))
                            else Text(tr(lang,"أدخل قياسين صحيحين: وزن الهواء يجب أن يكون أكبر من وزن الماء.","Enter valid readings: air weight must exceed submerged weight.","ትክክለኛ መለኪያ ያስገቡ።"),style=MaterialTheme.typography.bodySmall,color=Color.Gray)
                        }
                    }
                    Card(shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFFEAF1EE))) {
                        Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                            Text(tr(lang,"4. التحليل الجيولوجي والذكاء الاصطناعي","4. AI & geological analysis","4. AI እና ጂኦሎጂካል ትንተና"),fontWeight=FontWeight.Bold)
                            Text(tr(lang,"واجهة وتجهيز إدخال البيانات جاهزان. يلزم ربط خادم تحليل آمن وقواعد بيانات جيولوجية وأسعار سوقية قبل أن تظهر أسماء الأنواع والاحتمالات والأسعار الحقيقية.","The interface and data-entry flow are ready. A secure analysis server, geological datasets, and market-price feeds must be connected before real candidate IDs, probabilities, and prices can be returned.","የመተግበሪያ ገጽና የውሂብ ማስገቢያ ዝግጁ ናቸው። እውነተኛ የድንጋይ ስሞችና ዋጋዎች ከመታየታቸው በፊት የትንተና ሰርቨር፣ የጂኦሎጂ ውሂብና የገበያ ዋጋ ምንጮች መገናኘት አለባቸው።"))
                        }
                    }
                    Text(tr(lang,"الفحص عن بُعد: في الخدمة الكاملة سيرسل التطبيق الصورة والموقع والقياسات إلى خادم آمن، ويعيد تقريراً يمكن مشاركته مع خبير في أي مكان. لا نرسل الموقع إلا بعد موافقة المستخدم.","Remote review: in the full service, the app will send the photo, location, and measurements to a secure server and return a report shareable with a specialist anywhere. Location is sent only with user consent.","የርቀት ምርመራ፦ በሙሉ አገልግሎቱ ምስል፣ ቦታና መለኪያዎች ወደ ደህንነቱ የተጠበቀ ሰርቨር ይላካሉ። ቦታ የሚላከው በተጠቃሚ ፈቃድ ብቻ ነው።"),style=MaterialTheme.typography.bodySmall,color=Color(0xFF174B45))
                    Text(tr(lang,"السلامة: لا تكسر الحجر ولا تستخدم الأحماض أو الزئبق أو السيانيد أو اللهب. اختبار الخدش قد يتلف العينة؛ لا تنفذه على حجر قد يكون ثميناً.","Safety: do not crush samples or use acids, mercury, cyanide, or flame. Scratch tests can damage a specimen; avoid them on potentially valuable stones.","ደህንነት፦ ድንጋዩን አትሰብሩ፤ አሲድ፣ ሜርኩሪ፣ ሳይያናይድ ወይም እሳት አትጠቀሙ። የመቧጨር ሙከራ ናሙናውን ሊጎዳ ይችላል።"),style=MaterialTheme.typography.bodySmall,color=Color(0xFF8A4B32))
                }
            }
        }
    }
}

fun getLastLocation(context: Context): Location? {
    val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
    return providers.mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null } }
        .maxByOrNull { it.time }
}
