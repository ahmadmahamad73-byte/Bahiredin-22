# Gem & Metal AI — Android MVP 0.2

Android Studio starter project, multilingual Arabic / English / Amharic.

## Current prototype features\n- Two workflows: field exploration and individual sample inspection.
- Android app shell using Jetpack Compose.
- Image selection and camera launch.
- Optional location permission and last-known GPS coordinates.
- Manual location entry.
- Specific-gravity calculator using sample weight in air and suspended in water.
- Safety notes for field tests.

## Not yet connected\nThe camera currently captures/selects a still image; continuous live-camera recognition and augmented-reality overlays are not implemented. Those require a CameraX preview pipeline, on-device/server vision inference, geospatial matching, and careful confidence/uncertainty display. Remote expert sharing also needs a backend and user-controlled consent.
This is not yet a working online identification service. The AI image model, Ethiopian geological GIS layers, authoritative occurrence database, live market pricing feeds, cloud API, and secure server are not connected. No mineral identification or market value is fabricated by this prototype.

## Build
Open this folder in Android Studio, allow Gradle sync, install Android SDK 35, then run `app`.

## Online service architecture to implement next
1. Android sends the sample image, consented GPS coordinates, and field-test measurements to a secure backend over HTTPS.
2. Backend runs image classification and returns ranked candidates with calibrated confidence and reasons.
3. GIS service intersects GPS with verified geological units, mineral occurrence records, and published reports from the Geological Institute of Ethiopia (GIE). Store source, map scale, date, and spatial uncertainty.
4. Price service returns dated ranges by rough/cut grade, weight unit, and market (local/export), with citations and confidence. If no credible quote exists, show “price unavailable” rather than inventing one.
5. Identification report clearly distinguishes visual match, regional geological plausibility, field-test consistency, and laboratory confirmation.

## Field-test safety
Do not scratch, chip, heat, acid-test, or chemically treat a potentially valuable specimen. Specific gravity by hydrostatic weighing is useful only when performed carefully on a clean, unmounted sample; bubbles, porous material, inclusions, and measurement errors can distort results. Do not use mercury or cyanide.
